<?php

namespace App\Http\Controllers;

use App\Models\Game;
use App\Models\GeneralSetting;
use App\Models\News;
use Illuminate\Http\Request;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        $games = Game::get();
        $general = GeneralSetting::first();
        $newses = News::get();
            return view('pages.home',[
                'general' => $general,
                'games' => $games,
                'newses' => $newses
            ]);
    }
}
