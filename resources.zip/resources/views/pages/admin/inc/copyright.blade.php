<!-- FOOTER -->
<footer class="footer">
    <div class="container">
        <div class="row align-items-center flex-row-reverse">
            <div class="col-md-12 col-sm-12 text-center ">
                <p class="copy-p">Copyright © 2021 <a href="#">Foxytech</a>. Designed by <a href="#">  Foxytech.net </a> All rights reserved.</p>
            </div>
        </div>
    </div>
</footer>
<!-- FOOTER CLOSED -->