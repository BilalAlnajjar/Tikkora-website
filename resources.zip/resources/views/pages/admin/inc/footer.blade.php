		<!-- BACK-TO-TOP -->
		<a href="#top" id="back-to-top"><i class="fa fa-angle-up"></i></a>

		<!-- JQUERY JS -->
		<script src="/assets/js/jquery-3.4.1.min.js"></script>

		<!-- BOOTSTRAP JS -->
		<script src="/assets/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
		<script src="/assets/plugins/bootstrap/js/popper.min.js"></script>

		<!-- SPARKLINE JS-->
		<script src="/assets/js/jquery.sparkline.min.js"></script>

		<!-- CHART-CIRCLE JS-->
		<script src="/assets/js/circle-progress.min.js"></script>

		<!-- RATING STAR JS-->
		<script src="/assets/plugins/rating/jquery.rating-stars.js"></script>

		<!-- C3 CHART JS -->
		<script src="/assets/plugins/charts-c3/d3.v5.min.js"></script>
		<script src="/assets/plugins/charts-c3/c3-chart.js"></script>

		<!-- INPUT MASK JS-->
		<script src="/assets/plugins/input-mask/jquery.mask.min.js"></script>

		<!-- SIDEBAR JS -->
		<script src="/assets/plugins/sidebar/sidebar.js"></script>

        <!-- SIDE-MENU JS -->
		<script src="/assets/plugins/sidemenu/sidemenu.js"></script>

		<!-- CUSTOM SCROLL BAR JS-->
		<script src="/assets/plugins/scroll-bar/jquery.mCustomScrollbar.concat.min.js"></script>

		<!-- CUSTOM JS-->
		<script src="/assets/js/custom.js"></script>

		<!-- DATA TABLE JS-->
		<script src="/assets/plugins/datatable/jquery.dataTables.min.js"></script>
		<script src="/assets/plugins/datatable/dataTables.bootstrap4.min.js"></script>
		<script src="/assets/plugins/datatable/datatable.js"></script>
		<script src="/assets/plugins/datatable/dataTables.responsive.min.js"></script>

		<!-- FORMEDITOR JS -->
		<script src="/assets/js/summernote.js"></script>
		<script src="/assets/js/formeditor.js"></script>

		<!-- FILE UPLOADES JS -->
		<script src="/assets/plugins/fileuploads/js/fileupload.js"></script>
		<script src="/assets/plugins/fileuploads/js/file-upload.js"></script>

		<!-- SELECT2 JS -->
		<script src="/assets/plugins/select2/select2.full.min.js"></script>

		<!-- BOOTSTRAP-DATERANGEPICKER JS -->
		<script src="/assets/plugins/bootstrap-daterangepicker/moment.min.js"></script>
		<script src="/assets/plugins/bootstrap-daterangepicker/daterangepicker.js"></script>

		<!-- WYSIWYG Editor JS -->
		<script src="/assets/plugins/wysiwyag/jquery.richtext.js"></script>
		<script src="/assets/plugins/wysiwyag/wysiwyag.js"></script>

		<!-- FORMELEMENTS JS -->
		<script src="/assets/js/form-elements.js"></script>
		<!-- SUMMERNOTE JS -->
		<script src="/assets/plugins/summernote/summernote-bs4.js"></script>

		<!-- MULTI SELECT JS-->
		<script src="/assets/plugins/multipleselect/multiple-select.js"></script>
		<script src="/assets/plugins/multipleselect/multi-select.js"></script>

		<!-- DATEPICKER JS -->
		<script src="/assets/plugins/date-picker/spectrum.js"></script>
		<script src="/assets/plugins/date-picker/jquery-ui.js"></script>
		<script src="/assets/plugins/input-mask/jquery.maskedinput.js"></script>

		<!-- TIMEPICKER JS -->
		<script src="/assets/plugins/time-picker/jquery.timepicker.js"></script>
		<script src="/assets/plugins/time-picker/toggles.min.js"></script>

		<!-- GALLERY JS -->
		<script src="/assets/plugins/gallery/picturefill.js"></script>
        <script src="/assets/plugins/gallery/lightgallery.js"></script>
		<script src="/assets/plugins/gallery/lightgallery-1.js"></script>
        <script src="/assets/plugins/gallery/lg-pager.js"></script>
        <script src="/assets/plugins/gallery/lg-autoplay.js"></script>
        <script src="/assets/plugins/gallery/lg-fullscreen.js"></script>
        <script src="/assets/plugins/gallery/lg-zoom.js"></script>
        <script src="/assets/plugins/gallery/lg-hash.js"></script>
        <script src="/assets/plugins/gallery/lg-share.js"></script>

	</body>
</html>
