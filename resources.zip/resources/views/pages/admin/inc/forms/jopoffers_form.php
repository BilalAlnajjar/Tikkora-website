<div class="col-md-12">
        <div class="card">
        <div class="card-header">
            <h3 class="card-title">Add / Edite Jop Offers</h3>
        </div>
            <div class="card-body">
            
                <div class="row">
                    
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-body">
                                <div class="card-header">
                                    <h3 class="card-title">Add Jop Offers</h3>
                                </div>

                                <div class="col-lg-12 ">
                                    <div class="form-group field_wrapper">
                                        <label>Jop Title</label>
                                        <div class="row">
                                            <div class="col-md-11">
                                            <input type="text" class="form-control" placeholder="Enter your documents needed" name="field_name[]" value="" />
                                            </div>
                                            <div class="col-md-1">
                                            <a href="javascript:void(0)" class="btn btn-primary add_button" title="Add field">ADD</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-lg-12">
                                <div class="form-group">
                                    <label class="form-label">Departement</label>
                                    <select class="form-control select2-show-search" data-placeholder="Choose one (with searchbox)">
                                        <optgroup label="Mountain Time Zone">
                                            <option value="AZ">Departement 1</option>
                                            <option value="CO">Departement 2</option>
                                            <option value="ID">Departement 3</option>
                                            <option value="MT">Departement 4</option>
                                            <option value="NM">Departement 5</option>
                                            <option value="ND">Departement 6</option>
                                        </optgroup>
                                    </select>
                                </div>
                            </div>
                                    

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
            </div>

            
            <div class="card-footer">
                <a href="#" class="btn btn-success mt-1">Save</a>
                <a href="#" class="btn btn-danger mt-1">Cancel</a>
            </div>
        </div>

        <input type="hidden" id="up-click">
    </div>							
