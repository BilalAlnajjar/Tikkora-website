    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Create / Edite Empolies</h3>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-lg-4 col-xl-4 col-md-12 col-sm-12">
                        <div class="card">
                            <div class="card-body">
                                <div class="text-center">
                                    <div class="userprofile">
                                        <div class="userpic  brround"> <img src="assets/images/users/10.jpg" alt="" class="userpicimg"> </div>
                                        <h3 class="username text-dark mb-2">Elizabeth Dyer</h3>
                                        <p class="mb-1 text-muted">Web Developer, USA</p>
                                        <div class="custom-controls-stacked">
                                            <div class="row">
                                                <div class="col-lg-6">
                                                    <label class="custom-control custom-radio">
                                                        <input type="radio" class="custom-control-input" name="example-radios" value="option1" checked>
                                                        <span class="custom-control-label">Expert</span>
                                                    </label>
                                                </div>
                                                <div class="col-lg-6">
                                                    <label class="custom-control custom-radio">
                                                        <input type="radio" class="custom-control-input" name="example-radios" value="option1" >
                                                        <span class="custom-control-label">Professional</span>
                                                    </label>
                                                </div>
                                                <div class="col-lg-6">
                                                    <label class="custom-control custom-radio">
                                                        <input type="radio" class="custom-control-input" name="example-radios" value="option1" >
                                                        <span class="custom-control-label">Good</span>
                                                    </label>
                                                </div>
                                                <div class="col-lg-6">
                                                    <label class="custom-control custom-radio">
                                                        <input type="radio" class="custom-control-input" name="example-radios" value="option1" >
                                                        <span class="custom-control-label">Bigenner</span>
                                                    </label>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-body">
                                
                                <div class="col-md-12">
                                    <div class="bashx">
                                        <label for="upload-id" style="float: right; transform: translateY(7px)">ID</label>
                                        <span href="#" class="btn btn-primary btn-sm mt-1 mb-1" id="upload-click"><i class="fe fe-camera mr-1"></i>Upload ID</span> 
                                    <input type="file" class="inbash">
                                    </div>
                                </div>
                            </div>
                            <div class="card-body">
                                <div class="col-md-12">
                                    <div class="bashx">
                                    <label for="upload-passport" style="float: right; transform: translateY(7px)">Passport</label>
                                        <span href="#" class="btn btn-primary btn-sm mt-1 mb-1" id="upload-passport"><i class="fe fe-camera mr-1"></i>Upload Passport</span> 
                                    <input type="file" class="inbash">
                                    </div>
                                </div>
                                
                            </div>
                            <div class="card-body">
                                <div class="col-md-12">
                                    <div class="ml-auto mt-xl-2 mt-lg-0 ml-lg-2">
                                    <label class="custom-control custom-checkbox" style="margin-left: 35%;">
                                        <input type="checkbox" class="custom-control-input" name="example-checkbox1" value="option1" checked="">
                                        <span class="custom-control-label">Insurancc</span>
                                    </label>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-body">
                                <div class="">
                                <h5>Expeiance :</h5>
                                    <div class="text-center">
                                    
                                        <div class="custom-controls-stacked">
                                            <div class="row">
                                                <div class="col-lg-6">
                                                    <label class="custom-control custom-radio">
                                                        <input type="radio" class="custom-control-input" name="example-radios" value="option1" checked="">
                                                        <span class="custom-control-label">Expert</span>
                                                    </label>
                                                </div>
                                                <div class="col-lg-6">
                                                    <label class="custom-control custom-radio">
                                                        <input type="radio" class="custom-control-input" name="example-radios" value="option1" checked="">
                                                        <span class="custom-control-label">Professional</span>
                                                    </label>
                                                </div>
                                                <div class="col-lg-6">
                                                    <label class="custom-control custom-radio">
                                                        <input type="radio" class="custom-control-input" name="example-radios" value="option1" checked="">
                                                        <span class="custom-control-label">Good</span>
                                                    </label>
                                                </div>
                                                <div class="col-lg-6">
                                                    <label class="custom-control custom-radio">
                                                        <input type="radio" class="custom-control-input" name="example-radios" value="option1" checked="">
                                                        <span class="custom-control-label">Bigenner</span>
                                                    </label>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="card">
                        <div class="card-body">
                            <div class="col-md-12">
                                <div class="ml-auto mt-xl-2 mt-lg-0 ml-lg-2">
                                    <div class="bashx">
                                    <label for="upload-passport" style="float: right; transform: translateY(7px)">Certificaltion</label>
                                    <span href="#" class="btn btn-primary btn-sm mt-1 mb-1" id="upload-passport"><i class="fe fe-camera mr-1"></i>Upload Certificaltion</span>
                                    <input type="file" class="inbash">
                                    </div>
                                </div>
                            </div>
                            <hr>
                            <div class="col-md-12">
                                <div class="ml-auto mt-xl-2 mt-lg-0 ml-lg-2">
                                <label class="custom-control custom-checkbox" style="margin-left: 35%;">
                                    <input type="checkbox" class="custom-control-input" name="example-checkbox1" value="option1" checked="">
                                    <span class="custom-control-label">Name of certificaltion</span>
                                </label>
                                </div>
                            </div>
                        </div>
                        </div>
                        
                    </div>
                    <div class="col-lg-8 col-xl-8 col-md-12 col-sm-12">
                        <div class="card">
                            <div class="card-header">
                                <h3 class="card-title">Edit Profile</h3>
                            </div>
                            <div class="card-body">

                            <div class="col-lg-12">
                                <div class="form-group">
                                    <label for="exampleInputname">Name</label>
                                    <input type="text" class="form-control" id="exampleInputname" placeholder="Enter Name Empolie">
                                </div>
                            </div>

                            <div class="col-lg-12">
                                <div class="form-group">
                                    <label for="exampleInputname">E-mail</label>
                                    <input type="email" class="form-control" id="exampleInputname" placeholder="Enter Email Empolie">
                                </div>
                            </div>

                            <div class="col-lg-12">
                                <div class="form-group">
                                    <label for="exampleInputname">Salary</label>
                                    <input type="number" class="form-control" id="exampleInputname" placeholder="Enter Salary Empolie">
                                </div>
                            </div>

                            <div class="col-lg-12">
                                <div class="form-group">
                                    <label for="exampleInputname">Cominission</label>
                                    <input type="number" max="100" min="0" class="form-control" id="exampleInputname" placeholder="Enter Cominission Empolie By %">
                                </div>
                            </div>
                            
                            <div class="col-lg-12">
                                <div class="form-group">
                                    <label for="exampleInputname">Mobile</label>
                                    <input type="text" class="form-control" id="exampleInputname" placeholder="Enter Phone Number">
                                </div>
                            </div>

                            <div class="row">
                                
                                <div class="col-lg-4 bash-xxx">
                                    <div class="card shadow">
                                        <div class="card-header">
                                            <h3 class="mb-0 card-title">CV upload</h3>
                                        </div>
                                        <div class="card-body">
                                            <div class="dropify-wrapper" style="height: 312px;"><div class="dropify-message"><span class="file-icon"></span> <p>Drag and drop a file here or click</p><p class="dropify-error">Ooops, something wrong appended.</p></div><div class="dropify-loader"></div><div class="dropify-errors-container"><ul></ul></div><input type="file" class="dropify" data-height="300"><button type="button" class="dropify-clear">Remove</button><div class="dropify-preview"><span class="dropify-render"></span><div class="dropify-infos"><div class="dropify-infos-inner"><p class="dropify-filename"><span class="dropify-filename-inner"></span></p><p class="dropify-infos-message">Drag and drop or click to replace</p></div></div></div></div>
                                        </div>
                                    </div>
                                </div><!-- COL END -->
                                <div class="col-lg-4 bash-xxx">
                                    <div class="card shadow">
                                        <div class="card-header">
                                            <h3 class="mb-0 card-title">Jop Offer</h3>
                                        </div>
                                        <div class="card-body">
                                            <div class="dropify-wrapper" style="height: 312px;"><div class="dropify-message"><span class="file-icon"></span> <p>Drag and drop a file here or click</p><p class="dropify-error">Ooops, something wrong appended.</p></div><div class="dropify-loader"></div><div class="dropify-errors-container"><ul></ul></div><input type="file" class="dropify" data-height="300"><button type="button" class="dropify-clear">Remove</button><div class="dropify-preview"><span class="dropify-render"></span><div class="dropify-infos"><div class="dropify-infos-inner"><p class="dropify-filename"><span class="dropify-filename-inner"></span></p><p class="dropify-infos-message">Drag and drop or click to replace</p></div></div></div></div>
                                        </div>
                                    </div>
                                </div><!-- COL END -->
                                <div class="col-lg-4 bash-xxx">
                                    <div class="card shadow">
                                        <div class="card-header">
                                            <h3 class="mb-0 card-title">Contract</h3>
                                        </div>
                                        <div class="card-body">
                                            <div class="dropify-wrapper" style="height: 312px;"><div class="dropify-message"><span class="file-icon"></span> <p>Drag and drop a file here or click</p><p class="dropify-error">Ooops, something wrong appended.</p></div><div class="dropify-loader"></div><div class="dropify-errors-container"><ul></ul></div><input type="file" class="dropify" data-height="300"><button type="button" class="dropify-clear">Remove</button><div class="dropify-preview"><span class="dropify-render"></span><div class="dropify-infos"><div class="dropify-infos-inner"><p class="dropify-filename"><span class="dropify-filename-inner"></span></p><p class="dropify-infos-message">Drag and drop or click to replace</p></div></div></div></div>
                                        </div>
                                    </div>
                                </div><!-- COL END -->
                            </div>

                            </div>
                        </div>
                    </div>
                </div>
                
            </div>
            <div class="card-footer">
                <a href="#" class="btn btn-success mt-1">Save</a>
                <a href="#" class="btn btn-danger mt-1">Cancel</a>
            </div>
        </div>

        <input type="hidden" id="up-click">
    </div>							
